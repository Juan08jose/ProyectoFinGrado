/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ConexionDataBase;

import Clases.Movimiento;
import contenido.Movimientos;
import Clases.Pokemon;
import java.awt.Image;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

/**
 *
 * @author Juanm
 */
public class InteraccionDataBase {

    public static void aleatorizar() {
        try {
            Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pokemons", "root", "");
            Statement st = cn.createStatement();
            ArrayList<Integer> numeros = new ArrayList<>();
            for (int i = 1; i < 13; i++) {
                numeros.add(i);
            }
            int contador = 2;
            while (contador < 14) {
                int random = (int) (Math.round(Math.random() * (numeros.size() - 1)));
                st.executeUpdate("UPDATE MISPOKEMON SET Posicion = " + numeros.get(random) + " WHERE IDMIPOKEMON = " + contador);
                st.executeUpdate("UPDATE MISPOKEMON SET VidaActual = VIDA WHERE IDMIPOKEMON = " + contador);
                numeros.remove(random);
                contador++;
            }
            st.close();
            cn.close();
        } catch (SQLException ex) {
            Logger.getLogger(InteraccionDataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static Pokemon[] consulta(String comando) throws SQLException {
        Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pokemons", "root", "");
        Statement st = cn.createStatement();
        ResultSet rs = st.executeQuery(comando);
        Pokemon[] pokemon = new Pokemon[20];
        int contador = 0;
        while (rs.next()) {
            //Imagen del pokemon
            InputStream inputStreamImagen = rs.getBinaryStream("imagen");
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int bytesRead = -1;
            try {
                while ((bytesRead = inputStreamImagen.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
            } catch (IOException ex) {
                Logger.getLogger(InteraccionDataBase.class.getName()).log(Level.SEVERE, null, ex);
            }

            byte[] imageBytes = outputStream.toByteArray();

            // Crear un ImageIcon a partir del byte array
            ImageIcon imageIcon = new ImageIcon(imageBytes);
            Movimiento mov1 = sacarMov(rs.getInt("mov1"));
            Movimiento mov2 = sacarMov(rs.getInt("mov2"));
            Movimiento mov3 = sacarMov(rs.getInt("mov3"));
            Movimiento mov4 = sacarMov(rs.getInt("mov4"));
            pokemon[contador] = new Pokemon(rs.getInt("idMiPokemon"), rs.getString("nombre"), rs.getString("tipo1"),
                    rs.getString("tipo2"), mov1, mov2, mov3, mov4, rs.getInt("vida"), rs.getInt("vidaActual"), rs.getInt("ataque"),
                    rs.getInt("defensa"), rs.getInt("velocidad"), imageIcon.getImage());
            contador++;
        }
        rs.close();
        st.close();
        cn.close();
        return pokemon;
    }

    public static Movimiento sacarMov(int mov) {
        Movimiento movimiento = null;
        try {
            Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pokemons", "root", "");
            Statement st = cn.createStatement();
            ResultSet rsMov2 = st.executeQuery("SELECT*FROM MOVIMIENTOS M WHERE IDMOVIMIENTO = " + mov);
            //Gif del ataque
            while (rsMov2.next()) {
                byte[] gifBytes2 = rsMov2.getBytes("imagenMov");
                ImageIcon imageIconGif2 = new ImageIcon(gifBytes2);
                Image imageGif2 = imageIconGif2.getImage();
                movimiento = new Movimiento(rsMov2.getInt("idmovimiento"), rsMov2.getString("nombreMov"), rsMov2.getString("tipoMov"),
                        rsMov2.getInt("potencia"), rsMov2.getLong("probGolpeo"), rsMov2.getString("Descripcion"), 0, imageGif2);
            }
            rsMov2.close();
            st.close();
            cn.close();
        } catch (SQLException ex) {
            Logger.getLogger(InteraccionDataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
        return movimiento;
    }

    public static void guardar(String comando) throws SQLException {
        Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pokemons", "root", "");
        try (Statement st = cn.createStatement()) {
            st.executeUpdate(comando);
        }
    }

    public static Double cargar(String comando) throws SQLException {
        Statement st;
        ResultSet rs;
        double multiplicador = 1;
        try (Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pokemons", "root", "")) {
            st = cn.createStatement();
            rs = st.executeQuery(comando);
            while (rs.next()) {
                multiplicador = rs.getDouble("multiplicador");
            }
        }
        st.close();
        rs.close();
        
        return multiplicador;
    }
}
