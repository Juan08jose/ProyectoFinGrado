/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.awt.Image;

/**
 *
 * @author Juanm
 */
public class Movimiento {
    public int idMov;
    public String nombre;
    public String tipo;
    public String descripcion;
    public int potencia;
    public long precision;
    public Image gifAtaque;
    public int prioridad;

    public Movimiento(int idMov,String nombre, String tipo, int potencia, long precision,String descripcion , int prioridad, Image gifAtaque) {
        this.idMov = idMov;
        this.nombre=nombre;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.potencia = potencia;
        this.precision = precision;
        this.gifAtaque=gifAtaque;
        this.prioridad=prioridad;
    }
    
    public int getIdMov() {
        return idMov;
    }

    public void setIdMov(int idMov) {
        this.idMov = idMov;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    public long getPrecision() {
        return precision;
    }

    public void setPrecision(long precision) {
        this.precision = precision;
    }

    public Image getGifAtaque() {
        return gifAtaque;
    }

    public void setGifAtaque(Image gifAtaque) {
        this.gifAtaque = gifAtaque;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }
    
    
}
