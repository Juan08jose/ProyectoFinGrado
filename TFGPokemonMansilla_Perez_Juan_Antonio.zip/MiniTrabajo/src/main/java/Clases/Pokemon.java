/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.awt.Image;

/**
 *
 * @author Juanm
 */
public class Pokemon {
    public int idmipokemon;
    public String nombre;
    public String tipo1;
    public String tipo2;
    public int vidaTotal;
    public int vidaActual;
    public int ataque;
    public int defensa;
    public int velocidad;
    public Image imagen;
    public Movimiento mov1;
    public Movimiento mov2;
    public Movimiento mov3;
    public Movimiento mov4;

    public Pokemon(int idmipokemon,String nombre, String tipo1,String tipo2,  Movimiento mov1, Movimiento mov2, Movimiento mov3, Movimiento mov4,int vidaTotal, int vidaActual, int ataque,int defensa, int velocidad, Image imagen) {
        this.idmipokemon = idmipokemon;
        this.tipo1 = tipo1;
        this.tipo2 = tipo2;
        this.vidaTotal = vidaTotal;
        this.vidaActual = vidaActual;
        this.ataque = ataque;
        this.defensa=defensa;
        this.velocidad = velocidad;
        this.imagen = imagen;
        this.mov1 = mov1;
        this.mov2 = mov2;
        this.mov3 = mov3;
        this.mov4 = mov4;
        this.nombre = nombre;
    }

    public int getIdmipokemon() {
        return idmipokemon;
    }

    public void setIdmipokemon(int idmipokemon) {
        this.idmipokemon = idmipokemon;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getTipo() {
        return tipo1;
    }

    public void setTipo1(String tipo1) {
        this.tipo1 = tipo1;
    }
    public String getTipo2() {
        return tipo2;
    }

    public void setTipo2(String tipo2) {
        this.tipo2 = tipo2;
    }
    public int getVidaTotal() {
        return vidaTotal;
    }

    public void setVidaTotal(int vidaTotal) {
        this.vidaTotal = vidaTotal;
    }

    public int getVidaActual() {
        return vidaActual;
    }

    public void setVidaActual(int vidaActual) {
        this.vidaActual = vidaActual;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public int getDefensa() {
        return defensa;
    }

    public void setDefensa(int defensa) {
        this.defensa = defensa;
    }

    
    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    public Image getImagen() {
        return imagen;
    }

    public void setImagen(Image imagen) {
        this.imagen = imagen;
    }

    public Movimiento getMov1() {
        return mov1;
    }

    public void setMov1(Movimiento mov1) {
        this.mov1 = mov1;
    }

    public Movimiento getMov2() {
        return mov2;
    }

    public void setMov2(Movimiento mov2) {
        this.mov2 = mov2;
    }

    public Movimiento getMov3() {
        return mov3;
    }

    public void setMov3(Movimiento mov3) {
        this.mov3 = mov3;
    }

    public Movimiento getMov4() {
        return mov4;
    }

    public void setMov4(Movimiento mov4) {
        this.mov4 = mov4;
    }
    
    
}
