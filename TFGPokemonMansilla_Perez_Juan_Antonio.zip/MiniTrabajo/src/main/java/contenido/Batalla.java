package contenido;

import Clases.Pokemon;
import ConexionDataBase.InteraccionDataBase;
import java.awt.Color;
import java.awt.Image;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author becario tecnico
 */
public class Batalla extends javax.swing.JFrame {

    Pokemon[] pokemons;
    int NumEnemigo=6;

    /**
     * Creates new form Batalla
     */
    public Batalla(int NumEnemigo) {
        this.NumEnemigo=NumEnemigo;
        sacarPokemon();
        initComponents();
        Batalla.setSize(500, 400);
        setLocationRelativeTo(null);
        setBatalla();
    }


    public void setBatalla() {
        EscenaInicial();
        colorearVida();
        Timer t = new Timer(1600, e -> {
            empezarCombate();
        });
        t.setRepeats(false);
        t.start();
    }

    public void empezarCombate() {
        /*Metodo que da comienzo al combate cuando el pokemon sale de la pokeball*/
        NombreAliado.setVisible(true);
        VidaAliada.setVisible(true);
        VidaNumerosAliada.setVisible(true);
        Movimientos m = new Movimientos(this,NombreAliado,NombreEnemigo, NumEnemigo,PokemonEnemigo, PokemonAliado, AtaqueEnemigo, AtaqueAliado, this.pokemons, VidaAliada, VidaEnemiga, VidaNumerosAliada, VidaNumerosEnemiga);
        m.setSize(840, 229);
        VidaAliada.setValue(pokemons[0].vidaActual * 100 / pokemons[0].vidaTotal);
        NombreAliado.setText(pokemons[0].getNombre());
        VidaNumerosAliada.setText(pokemons[0].getVidaActual() + " / " + pokemons[0].getVidaTotal());
        Image resizedImage = pokemons[0].getImagen().getScaledInstance(PokemonAliado.getWidth(), PokemonAliado.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
        PokemonAliado.setIcon(resizedIcon);
        Acciones.add(m);
        Acciones.revalidate();
        Acciones.repaint();
    }

    public void colorearVida() {
        /*Colorea las barras de vida*/
        if ((pokemons[NumEnemigo].getVidaActual()*100/pokemons[NumEnemigo].getVidaTotal()) > 50) {
            VidaEnemiga.setForeground(Color.green);
        } else if ((pokemons[NumEnemigo].getVidaActual()*100/pokemons[NumEnemigo].getVidaTotal()) < 50 && (pokemons[NumEnemigo].getVidaActual()*100/pokemons[NumEnemigo].getVidaTotal())> 30) {
            VidaEnemiga.setForeground(Color.yellow);
        } else {
            VidaEnemiga.setForeground(Color.red);
        }
        if ((pokemons[0].getVidaActual()*100/pokemons[0].getVidaTotal())> 50) {
            VidaAliada.setForeground(Color.green);
        } else if ((pokemons[0].getVidaActual()*100/pokemons[0].getVidaTotal()) < 50 && (pokemons[0].getVidaActual()*100/pokemons[0].getVidaTotal()) > 30) {
            VidaAliada.setForeground(Color.yellow);
        } else {
            VidaAliada.setForeground(Color.red);
        }
    }

    public void EscenaInicial() {
        /*
        *   Pone el fondo y el pokemon que controlas, sale de una pokeball
        */
        ImageIcon IFondo = new ImageIcon("Imagenes/FondoBatalla.png");
        Image originalFondo = IFondo.getImage();
        Image resizedImageFondo = originalFondo.getScaledInstance(Fondo.getWidth(), Fondo.getHeight(), Image.SCALE_DEFAULT);
        ImageIcon resizedIconFondo = new ImageIcon(resizedImageFondo);
        Fondo.setIcon(resizedIconFondo);
        ImageIcon IPokeball = new ImageIcon("Imagenes/Pokeball.gif");
        Image originalPokeball = IPokeball.getImage();
        Image resizedImagePokeball = originalPokeball.getScaledInstance(Fondo.getWidth(), Fondo.getHeight(), Image.SCALE_DEFAULT);
        ImageIcon resizedIconPokeball = new ImageIcon(resizedImagePokeball);
        PokemonAliado.setIcon(resizedIconPokeball);
        NombreAliado.setVisible(false);
        VidaAliada.setVisible(false);
        VidaNumerosAliada.setVisible(false);
        Image resizedImage1 = pokemons[NumEnemigo].getImagen().getScaledInstance(PokemonEnemigo.getWidth(), PokemonEnemigo.getHeight(), Image.SCALE_DEFAULT);
        ImageIcon resizedIcon1 = new ImageIcon(resizedImage1);
        PokemonEnemigo.setIcon(resizedIcon1);
        VidaEnemiga.setValue(pokemons[NumEnemigo].vidaActual * 100 / pokemons[NumEnemigo].getVidaTotal());
        NombreEnemigo.setText(pokemons[NumEnemigo].getNombre());
        VidaNumerosEnemiga.setText(pokemons[NumEnemigo].getVidaActual() + " / " + pokemons[NumEnemigo].getVidaTotal());
    }

    public void sacarPokemon() {
        try {
            pokemons = InteraccionDataBase.consulta("Select * from mispokemon mp ORDER BY Posicion");
        } catch (SQLException ex) {
            Logger.getLogger(Batalla.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void victoria()
    {
        Victoria v = new Victoria();
        v.setVisible(true);
        this.setVisible(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Batalla = new javax.swing.JPanel();
        Visual = new javax.swing.JPanel();
        VidaAliada = new javax.swing.JProgressBar();
        VidaEnemiga = new javax.swing.JProgressBar();
        AtaqueAliado = new javax.swing.JLabel();
        AtaqueEnemigo = new javax.swing.JLabel();
        PokemonAliado = new javax.swing.JLabel();
        PokemonEnemigo = new javax.swing.JLabel();
        NombreEnemigo = new javax.swing.JLabel();
        NombreAliado = new javax.swing.JLabel();
        VidaNumerosAliada = new javax.swing.JLabel();
        VidaNumerosEnemiga = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        Fondo = new javax.swing.JLabel();
        Acciones = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Batalla.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Visual.setBackground(new java.awt.Color(204, 255, 255));
        Visual.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        Visual.add(VidaAliada, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 270, 190, 20));
        Visual.add(VidaEnemiga, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 60, 190, 20));
        Visual.add(AtaqueAliado, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 70, 200, 200));
        Visual.add(AtaqueEnemigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, 200, 200));
        Visual.add(PokemonAliado, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, 200, 200));
        Visual.add(PokemonEnemigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 70, 200, 200));

        NombreEnemigo.setText("jLabel1");
        Visual.add(NombreEnemigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 40, 160, -1));

        NombreAliado.setText("jLabel1");
        Visual.add(NombreAliado, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 250, 160, -1));

        VidaNumerosAliada.setText("jLabel1");
        Visual.add(VidaNumerosAliada, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 290, 190, 30));

        VidaNumerosEnemiga.setText("jLabel2");
        Visual.add(VidaNumerosEnemiga, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 80, 190, 30));

        jButton1.setBackground(new java.awt.Color(204, 255, 255));
        jButton1.setText("Ayuda");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        Visual.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 70, 70));

        Fondo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Visual.add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 390));

        Batalla.add(Visual, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 386));

        Acciones.setBackground(new java.awt.Color(96, 159, 158));
        Acciones.setPreferredSize(new java.awt.Dimension(733, 110));

        javax.swing.GroupLayout AccionesLayout = new javax.swing.GroupLayout(Acciones);
        Acciones.setLayout(AccionesLayout);
        AccionesLayout.setHorizontalGroup(
            AccionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        AccionesLayout.setVerticalGroup(
            AccionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 220, Short.MAX_VALUE)
        );

        Batalla.add(Acciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 380, 900, 220));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Batalla, javax.swing.GroupLayout.PREFERRED_SIZE, 898, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Batalla, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Ayuda a = new Ayuda();
        a.setVisible(true);
        JOptionPane.showMessageDialog(this,"Dejo la tabla de tipos en una ventana aparte por si necesitas mirarla");
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Acciones;
    private javax.swing.JLabel AtaqueAliado;
    private javax.swing.JLabel AtaqueEnemigo;
    private javax.swing.JPanel Batalla;
    private javax.swing.JLabel Fondo;
    private javax.swing.JLabel NombreAliado;
    private javax.swing.JLabel NombreEnemigo;
    private javax.swing.JLabel PokemonAliado;
    private javax.swing.JLabel PokemonEnemigo;
    private javax.swing.JProgressBar VidaAliada;
    private javax.swing.JProgressBar VidaEnemiga;
    private javax.swing.JLabel VidaNumerosAliada;
    private javax.swing.JLabel VidaNumerosEnemiga;
    private javax.swing.JPanel Visual;
    private javax.swing.JButton jButton1;
    // End of variables declaration//GEN-END:variables
}
